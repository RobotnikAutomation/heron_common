#!/usr/bin/python

import rospy

import actionlib

import mbf_msgs.msg

import std_srvs.srv

def main():
    rospy.init_node('ask_confirmation')

    plan_client = actionlib.SimpleActionClient('/move_base_flex/get_path', mbf_msgs.msg.GetPathAction)
    plan_client.wait_for_server()
    plan_goal = mbf_msgs.msg.GetPathGoal()
    plan_goal.target_pose.header.frame_id = 'odom'
    plan_goal.target_pose.pose.position.x = 5
    plan_goal.target_pose.pose.position.y = 3
    plan_goal.target_pose.pose.orientation.z = 1
    plan_goal.target_pose.pose.orientation.w = 0
    plan_goal.tolerance = 0.2
    print 'asking for plan'
    plan_client.send_goal(plan_goal)
    plan_client.wait_for_result()
    plan = plan_client.get_result()

    print 'got plan, has ' + str(len(plan.path.poses)) + ' poses'

    print 'asking for confirmation'
    confirmation_client = rospy.ServiceProxy('/confirmation', std_srvs.srv.SetBool)
    confirmation = confirmation_client()

    if confirmation.success == True:
        print 'plan confirmed, start navigation' 
        navigate_client = actionlib.SimpleActionClient('/move_base_flex/exe_path', mbf_msgs.msg.ExePathAction)
        navigate_client.wait_for_server()
        navigate_goal = mbf_msgs.msg.ExePathGoal()
        navigate_goal.path = plan.path
        navigate_client.send_goal(navigate_goal)
        navigate_client.wait_for_result()
    else:
        print 'plan not confirmed, bye!'

if __name__ == '__main__':
    main()
