
"use strict";

let RobotnikMoveBaseFlexGoalAction = require('./RobotnikMoveBaseFlexGoalAction.js');
let PoseStampedArray = require('./PoseStampedArray.js');
let RobotnikMoveBaseFlexFeedbackAction = require('./RobotnikMoveBaseFlexFeedbackAction.js');
let RobotnikMoveBaseFlexResultAction = require('./RobotnikMoveBaseFlexResultAction.js');
let MoveActionResult = require('./MoveActionResult.js');
let RobotnikMoveBaseFlexResult = require('./RobotnikMoveBaseFlexResult.js');
let BarcodeDockGoal = require('./BarcodeDockGoal.js');
let MoveGoal = require('./MoveGoal.js');
let BarcodeDockAction = require('./BarcodeDockAction.js');
let BarcodeDockResult = require('./BarcodeDockResult.js');
let DockActionResult = require('./DockActionResult.js');
let BarcodeDockActionResult = require('./BarcodeDockActionResult.js');
let MoveResult = require('./MoveResult.js');
let MoveAction = require('./MoveAction.js');
let MoveActionFeedback = require('./MoveActionFeedback.js');
let RobotnikMoveBaseFlexFeedback = require('./RobotnikMoveBaseFlexFeedback.js');
let BarcodeDockActionGoal = require('./BarcodeDockActionGoal.js');
let RobotnikMoveBaseFlexGoal = require('./RobotnikMoveBaseFlexGoal.js');
let DockGoal = require('./DockGoal.js');
let BarcodeDockActionFeedback = require('./BarcodeDockActionFeedback.js');
let MoveActionGoal = require('./MoveActionGoal.js');
let DockAction = require('./DockAction.js');
let DockFeedback = require('./DockFeedback.js');
let DockResult = require('./DockResult.js');
let DockActionGoal = require('./DockActionGoal.js');
let RobotnikMoveBaseFlexActionGoal = require('./RobotnikMoveBaseFlexActionGoal.js');
let BarcodeDockFeedback = require('./BarcodeDockFeedback.js');
let RobotnikMoveBaseFlexAction = require('./RobotnikMoveBaseFlexAction.js');
let DockActionFeedback = require('./DockActionFeedback.js');
let RobotnikMoveBaseFlexActionFeedback = require('./RobotnikMoveBaseFlexActionFeedback.js');
let MoveFeedback = require('./MoveFeedback.js');
let RobotnikMoveBaseFlexActionResult = require('./RobotnikMoveBaseFlexActionResult.js');

module.exports = {
  RobotnikMoveBaseFlexGoalAction: RobotnikMoveBaseFlexGoalAction,
  PoseStampedArray: PoseStampedArray,
  RobotnikMoveBaseFlexFeedbackAction: RobotnikMoveBaseFlexFeedbackAction,
  RobotnikMoveBaseFlexResultAction: RobotnikMoveBaseFlexResultAction,
  MoveActionResult: MoveActionResult,
  RobotnikMoveBaseFlexResult: RobotnikMoveBaseFlexResult,
  BarcodeDockGoal: BarcodeDockGoal,
  MoveGoal: MoveGoal,
  BarcodeDockAction: BarcodeDockAction,
  BarcodeDockResult: BarcodeDockResult,
  DockActionResult: DockActionResult,
  BarcodeDockActionResult: BarcodeDockActionResult,
  MoveResult: MoveResult,
  MoveAction: MoveAction,
  MoveActionFeedback: MoveActionFeedback,
  RobotnikMoveBaseFlexFeedback: RobotnikMoveBaseFlexFeedback,
  BarcodeDockActionGoal: BarcodeDockActionGoal,
  RobotnikMoveBaseFlexGoal: RobotnikMoveBaseFlexGoal,
  DockGoal: DockGoal,
  BarcodeDockActionFeedback: BarcodeDockActionFeedback,
  MoveActionGoal: MoveActionGoal,
  DockAction: DockAction,
  DockFeedback: DockFeedback,
  DockResult: DockResult,
  DockActionGoal: DockActionGoal,
  RobotnikMoveBaseFlexActionGoal: RobotnikMoveBaseFlexActionGoal,
  BarcodeDockFeedback: BarcodeDockFeedback,
  RobotnikMoveBaseFlexAction: RobotnikMoveBaseFlexAction,
  DockActionFeedback: DockActionFeedback,
  RobotnikMoveBaseFlexActionFeedback: RobotnikMoveBaseFlexActionFeedback,
  MoveFeedback: MoveFeedback,
  RobotnikMoveBaseFlexActionResult: RobotnikMoveBaseFlexActionResult,
};
